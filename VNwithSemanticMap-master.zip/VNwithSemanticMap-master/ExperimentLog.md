### Experiment Log

* Model trained with setting: 1 house 4 targets:

* Fine-tune the model trained above with Policy Gradient.

* Model trained with setting: 4 houses 4 targets; and tested in 1 house 4 targets.

* Train a Mapper with [VPN](https://github.com/pbw-Berwin/View-Parsing-Network) with MatterPort3D dataset.
