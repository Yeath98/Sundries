# Components - 组件

## CTitleBar
 - [使用方法](../TestCTitleBar.py)
 - ![CTitleBar](../ScreenShot/CTitleBar.gif)

## CFramelessWidget
 - [使用方法](../TestCFramelessWidget.py)
 - ![CFramelessWidget](../ScreenShot/CFramelessWidget.gif)

## CColorPicker
 - [使用方法](../TestCColorPicker.py)
 - ![CColorPicker](../ScreenShot/CColorPicker.gif)

## CPaginationBar
 - [使用方法](../TestCPaginationBar.py)
 - ![CPaginationBar](../ScreenShot/CPaginationBar.gif)

## CDrawer
 - [使用方法](../TestCDrawer.py)
 - ![CDrawer](../ScreenShot/CDrawer.gif)

## CAvatar
 - [使用方法](../TestCAvatar.py)
 - ![CAvatar](../ScreenShot/CAvatar.gif)

## CLoadingBar
 - [使用方法](../TestCLoadingBar.py)
 - ![CLoadingBar](../ScreenShot/CLoadingBar.gif)

## CCountUp
 - [使用方法](../TestCCountUp.py)
 - ![CCountUp](../ScreenShot/CCountUp.gif)