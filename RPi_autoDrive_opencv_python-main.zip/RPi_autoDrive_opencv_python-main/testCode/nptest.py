#-*- coding:UTF-8 -*-

import numpy as np


x=np.arange(10)
y=np.arange(10)
np.savez('./training_data/'+'save_x1')