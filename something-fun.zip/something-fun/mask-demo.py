import cv2
detector = cv2.CascadeClassifier(r'F:\Py_experiment\venv\Scripts\python\Lib\site-packages\cv2\data\haarcascade_frontalface_alt.xml')

mask_detector = cv2.CascadeClassifier('F:\Py_experiment\T1\cascade.xml')
cap = cv2.VideoCapture(0)

while True:
    ret, img = cap.read()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = detector.detectMultiScale(gray, 1.1, 3)
    for (x, y, w, h) in faces:
        # 参数分别为 图片、左上角坐标，右下角坐标，颜色，厚度
        face = img[y:y + h, x:x + w]  # 裁剪坐标为[y0:y1, x0:x1]
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
        # 在左半部分最上方打印文字
        cv2.putText(img,'No MASK',(x, y), cv2.FONT_HERSHEY_SIMPLEX,0.5,(0, 0, 255),2)

        mask_face = mask_detector.detectMultiScale(gray, 1.1, 5)

        for (x2, y2, w2, h2) in mask_face:
            cv2.rectangle(img, (x2, y2), (x2 + w2, y2 + h2), (255, 0, 255), 2)
            cv2.putText(img, 'MASK', (x2, y2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

    cv2.imshow('test', img)
    cv2.waitKey(3)

cap.release()
cv2.destroyAllWindows()